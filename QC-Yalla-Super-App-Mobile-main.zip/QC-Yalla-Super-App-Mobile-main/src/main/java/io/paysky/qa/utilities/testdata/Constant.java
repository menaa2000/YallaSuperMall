package io.paysky.qa.utilities.testdata;

public class Constant {
    public static final String MSISDN = "01064890323";
    public static final String PIN_NUMBER = "1991";
    public static final String PHONE_VERIFICATION_CODE = "1111";

    public static final String EMAIL = "Semaduddin@gmail.com";


    // request money data
    public static  final String registeredMsisdin = "01009439485" ;

    //Has no cards
    public static  final String registeredMsisdin2 = "01005351664" ;
    public static final String  unregisteredMsisdin = "0100123698" ;

    public static final String Location = "Cairo";

}
